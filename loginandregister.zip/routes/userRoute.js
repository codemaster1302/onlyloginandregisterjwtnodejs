const express = require("express");

const user_route = express();

const bodyParser = require("body-parser");

user_route.use(bodyParser.json());
user_route.use(bodyParser.urlencoded({extended:true}));

const multer = require("multer");

const path = require("path");
const fs = require('fs');

user_route.use(express.static('public'));

const storage = multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,path.join(__dirname,'../public/userImages'),function(error,success){
            if(error) throw error
        })

    },
    filename:function(req,file,cb){
        const name = Date.now()+'-'+file.originalname;
        cb(null,name,function(error1,success1){
            if(error1) throw error1
        })
    }
});

const upload = multer({storage:storage});

const user_constroller = require("../controllers/userController");

const auth = require("../middleware/auth");

user_route.post('/register',upload.single('image'),user_constroller.register_user);
user_route.post('/login',user_constroller.user_login);



user_route.get('/test', auth,async (req,res) => {
    res.status(200).send({success:true,msg: "Auth Valid"})
});

user_route.get('/withoutauth',async (req,res) => {
    res.status(200).send({success:true,msg: "No required Auth Valid"})
});

module.exports = user_route;