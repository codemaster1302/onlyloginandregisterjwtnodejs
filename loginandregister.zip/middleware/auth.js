const jwt  = require("jsonwebtoken");
const { secret_jwt } = require("../config/config");
const config = require("../config/config");

const verifyToken = async (req,res,next) => {
    const token = req.body.token || req.query.token || req.headers["authorization"];

    if(!token){
        return res.status(200).json({success:false,msg:"A token is required for authentication"});
    }

    try {
        const descode = jwt.verify(token,config.secret_jwt);
        req.user = descode;
    } catch (error) {
        return res.status(400).json({success:false,msg:"invalid token"});
    }

    return next();

}

module.exports = verifyToken;