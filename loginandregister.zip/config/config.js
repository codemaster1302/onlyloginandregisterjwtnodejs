const config = {
    secret_jwt:"thisismysecretkey"
}

module.exports = config;