const User = require("../models/userModel");
const bcryptjs = require("bcryptjs");
const path = require('path');
const fs = require('fs');
const config = require("../config/config");

const jwt = require("jsonwebtoken");

const create_token =  async(id) => {

    try {
        const token = await jwt.sign({_id:id},config.secret_jwt);
        return token;

    } catch (error) {
        res.status(400).send(error.message);
    }

}


const securePassword = async (password) => {
    try {
        const passwordHash = await bcryptjs.hash(password, 10);
        return passwordHash;
    } catch (error) {
        res.status(400).send(error.message);
    }
}

// body post save data without base64 image
// const register_user = async(req,res) =>{
//     try{

//         const spassword = await securePassword(req.body.password);



//         const user = new User({
//             name:req.body.name,
//             email:req.body.email,
//             password:spassword,
//             mobile:req.body.mobile,
//             image:req.file.filename,
//             type:req.body.type
//         });

//         const userData = await User.findOne({email:req.body.email});
//         if(userData){
//             res.status(200).send({success:false,msg:"This email alredy exists"});
//         }else{
//             const user_data = await user.save();
//             res.status(200).send({success:true,data:user_data});

//         }

//     }catch (error){
//         res.status(400).send(error.message);
//     }
// }


// json wise upload with base64 image
const register_user = async (req, res) => {
    try {
        let fileName = "";
        const encoded = req.body.image;
        const base64ToArray = encoded.split(";base64,");
        const prefix = base64ToArray[0];
        const extension = prefix.replace(/^data:image\//, '');
        //const extension = 'jpg';

        if (extension === 'jpeg' || extension === 'jpg' || extension === 'png') {
            const imageData = base64ToArray[1];
            fileName = (new Date().getTime() / 1000 | 0) + '.' + extension;
            const imagePath = path.join(__dirname, './../public/userImages/') + fileName;
            fs.writeFileSync(imagePath, imageData, { encoding: 'base64' });

            // return res.status(201).json({
            //     error: false,
            //     message: "Base64 Image was successfully uploaded.",
            //     url: `/images/${fileName}`
            // });
        }
        else {
            return res.status(403).json({
                error: true,
                message: "Base64 data not valid!",
            });
        }
        const spassword = await securePassword(req.body.password);


        const user = new User({
            name: req.body.name,
            email: req.body.email,
            password: spassword,
            mobile: req.body.mobile,
            image: fileName,
            type: req.body.type
        });

        const userData = await User.findOne({ email: req.body.email });
        if (userData) {
            res.status(200).send({ success: false, msg: "This email alredy exists" });
        } else {
            const user_data = await user.save();
            res.status(200).send({ success: true, data: user_data });

        }

    } catch (error) {
        res.status(400).send(error.message);
    }
}

const user_login = async (req,res) => {

    try {

        const email = req.body.email;
        const password = req.body.password;

        const userData = await User.findOne({email:email});
        if(userData){
            const passwordMatch = await bcryptjs.compare(password,userData.password);
            if(passwordMatch){
                   const tokenData = await create_token(userData._id);
                    const userResult = {
                        _id:userData._id,
                        name:userData.name,
                        email:userData.email,
                        password:userData.password,
                        image:userData.image,
                        mobile:userData.mobile,
                        type:userData.type,
                        token:tokenData
                    }

                    const response = {
                        success:true,
                        msg:"user details",
                        data:userResult
                    }

                    res.status(200).send(response);
            }else{
                res.status(200).send({success:false,msg:"Login details are incorrect"});
            }
        }else{
            res.status(200).send({success:false,msg:"Login details are incorrect"});
        }
        
    } catch (error) {
        res.status(400).send(error.message);
    }

}

module.exports = {
    register_user,
    user_login
}


